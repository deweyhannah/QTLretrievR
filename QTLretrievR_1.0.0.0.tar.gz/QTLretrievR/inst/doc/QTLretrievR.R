## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(QTLretrievR)

## ----quick_start, eval = FALSE------------------------------------------------
#  ## Passing a Genoprobs object - list of probabilities for each tissue
#  ## Using internal data for expr, gridFile, metadata, annots
#  
#  qtl_res <- runQTL(outdir = "../vignettes/",
#                    gbrs_fileLoc = list("mESC" = demo_probs),
#                    geno_out = "mESC_mm10_probs.rds",
#                    peaks_out = "mESC_mm10_peaks.rds",
#                    map_out = "mESC_mm10_map.rds",
#                    med_out = "mESC_mm10_mediation.rds",
#                    effects_out = "mESC_mm10_effects.rds",
#                    expr_mats = list("mESC" = demo_counts),
#                    tissues = "mESC",
#                    gridFile = gridfile69k,
#                    covar_factors = c("sex"),
#                    metadata = demo_meta,
#                    annots = demo_annot,
#                    save_t = "ro")

## ----quick_start_file_in, eval = FALSE----------------------------------------
#  ## Unevaluated Code Chunk
#  
#  qtl_res <- runQTL(outdir = <path/to/output/dir>,
#                    gbrs_fileLoc = <path/to/gbrs/files>,
#                    geno_out = "Name_for_genotype_prob_file.rds",
#                    peaks_out = "Name_for_QTL_peaks.rds",
#                    map_out = "Name_for_mapping_objects.rds",
#                    med_out = "Name_for_mediation_Results.rds",
#                    effects_out = "Name_for_QTL_effects.rds",
#                    expr_mats = c(<path/to/expr_mat1>, <path/to/expr_mat2>),
#                    tissues = "Tissue_name",
#                    gridFile = <path/to/gridfile>,
#                    covar_factors = c("Covariates"),
#                    metadata = <path/to/sample/metadata>,
#                    annots = <path/to/annotations>,
#                    save = "ro"
#                    )
#  

## ----probs_ex-----------------------------------------------------------------
## Structure and example of qtl2 fomatted genoprobs
names(demo_probs)
str(demo_probs[[1]])
demo_probs[[1]][1:2,,1:2]

## ----counts_ex----------------------------------------------------------------
## Information and partial example of quantified data
class(demo_counts)
head(demo_counts)

## ----marker_ex----------------------------------------------------------------
## example format for 75K marker grid
head(gridfile)

## ----meta_ex------------------------------------------------------------------
## minimal metadata example
head(demo_meta[which(demo_meta$ID %in% colnames(demo_counts)),])

## ----annot_ex-----------------------------------------------------------------
## Example annotation file - Note this file is all the genes for the Ensemblv84 build
head(demo_annot)

## ----genoprobably, eval=FALSE-------------------------------------------------
#  ## Unevaluated Code Chunk
#  probs <- genoprobably(outfile     = "../../vignette/gbrs_interpolated_probs.rds",
#                        gbrsFileLoc = "<path/to/gbrs/results>",
#                        tissues     = c("tissue1","tissue2"),
#                        gridFile    = gridfile,
#                        save        = "ro")

## ----mugaprobs, eval=FALSE----------------------------------------------------
#  ## Unevaluated Code Chunk
#  
#  probs <- mugaprobs(type       = "GM",                                   # Did your genotyping come from GigaMUGA or MegaMUGA?
#                     covarLoc   = "/path/to/covariate/file/",
#                     covar_file = "name_of_covariate_file.tsv",
#                     i.files    = c("final_report_1", "final_report_2"),  # If you already have chromosome specific genotype files you can pass that directory as a string here
#                     genoPrefix = "gm4qtl2",
#                     probsOut   = "muga_interpolated_genoprobs.rds",      # This is the file that your probabilites will be saved to
#                     tissues    = c("tissue1", "tissue2"))                # All probabilities will be attributed to each tissue, this is just to put it in the format needed for `mapQTL`
#  

## ----mapQTL, eval=FALSE-------------------------------------------------------
#  ## Unevaluated Code Chunk
#  ## Passing objects:
#  map_peaks <- mapQTL(outdir        = "../../vignette/",
#                      peaks_out     = "mm39_peaks.rds",
#                      map_out       = "mm39_map.rds",
#                      genoprobs     = probs,
#                      samp_meta     = demo_meta,                   # Make sure that your ID column is named "ID"
#                      expr_mats     = list("mESC" = demo_counts),  # Pass your counts as a named list
#                      covar_factors = c("sex"),
#                      gridFile      = gridfile,
#                      annots        = demo_annot,                  # See the Annotations section above for notes on this
#                      save          = "ro")                        # return only - other options are "so" (save only) and "sr" (save and return)
#  
#  ## Passing file locations
#  map_peaks <- mapQTL(outdir        = "../../vignette/",
#                      peaks_out     = "mm39_peaks.rds",
#                      map_out       = "mm39_map.rds",
#                      genoprobs     = "path/to/saved/probs.rds",
#                      samp_meta     = "path/to/sample/metadata",
#                      expr_mats     = c("path/to/counts1","path/to/coounts/2"),
#                      covar_factors = c("sex"),
#                      gridFile      = "path/to/custom/grid",
#                      annots        = "path/to/annotations",
#                      save          = "ro")

## ----qtl_mediate, eval=FALSE--------------------------------------------------
#  ## Unevaluated Code Chunk
#  med_res <- run_mediate(peaks   = map_peaks$peaks_list,
#                         mapping = map_peaks$maps_list,
#                         outdir  = "../../vignette",
#                         annots  = demo_annot,
#                         suggLOD = 7,
#                         med_out = "mm39_mediation.rds",
#                         save    = "ro")

## ----qtl_effects, eval=FALSE--------------------------------------------------
#  ## Unevaluated Code Chunk
#  effects <- qtl_effects(mapping = map_peaks$maps_list,
#                         peaks   = map_peaks$peaks_list,
#                         suggLOD = 7,
#                         outdir  = "../../vignette",
#                         outfile = "mm39_effects.rds",
#                         save    = "ro")

